// @ts-check

import { test } from 'node:test';
import assert from 'assert/strict';
import Validator from '../index.js';

test('step1', () => {
  const v = new Validator();
  const phoneSchema = v.phone();

  assert.equal(phoneSchema.isValid('+3809876543'), true);
  assert.equal(phoneSchema.isValid('+79123456789'), true);
  assert.equal(phoneSchema.isValid('+15551234567'), true);
  assert.equal(phoneSchema.isValid('+4471234567'), true);
  assert.equal(phoneSchema.isValid('invalid-phone'), false);
  assert.equal(phoneSchema.isValid(15613854), false);
});

test('step2', () => {
  const v = new Validator();

  const phoneSchema1 = v.phone();
  assert.equal(phoneSchema1.isValid('+380987654321'), true);

  const phoneSchema2 = v.phone().setPhoneLengthConstraint(7);
  assert.equal(phoneSchema2.isValid('+19123456789'), true);
  assert.equal(phoneSchema2.isValid('+3809'), false);

  const phoneSchema3 = v.phone().setPhoneLengthConstraint(2, 5);
  assert.equal(phoneSchema3.isValid('+447'), true);
  assert.equal(phoneSchema3.isValid('+94684684'), false);
});

test('step3', () => {
  const v = new Validator();
  const ratingValidator = v.getRating();

  assert.equal(ratingValidator.isValid(7.5), true);
  assert.equal(ratingValidator.isValid('7.5'), false);
  assert.equal(ratingValidator.isValid('lolololo'), false);
  assert.equal(ratingValidator.isValid(10), true);
  assert.equal(ratingValidator.isValid(0), false);
  assert.equal(ratingValidator.isValid(11), false);
  assert.equal(ratingValidator.isValid(5.5), true);
});

test('step4', () => {
  const v = new Validator();

  const ratingValidator1 = v.getRating();
  assert.equal(ratingValidator1.isValid(7.5), true);

  const ratingValidator2 = v.getRating().setHighRatingValidator();
  assert.equal(ratingValidator2.isValid(7.5), false);
  assert.equal(ratingValidator2.isValid(8), true);
});

test('step5', () => {
  const v = new Validator();
  const userSchema = v.user().shape({
    phone: v.phone().setPhoneLengthConstraint('7'),
    rating: v.getRating().setHighRatingValidator(),
  });

  assert.equal(userSchema.isValid({ phone: '+19123453', rating: 9.5 }), true);
  assert.equal(userSchema.isValid({ phone: '+45454', rating: 7.5 }), false);
});
